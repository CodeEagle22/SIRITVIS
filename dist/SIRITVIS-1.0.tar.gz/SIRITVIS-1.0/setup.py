from setuptools import setup, find_packages

setup(
    name='SIRITVIS',
    version='1.0',
    author='Sagar Narwade, Gillian Kant, Benjamin Saefken',
    description="SIRITVIS: Social Media Interaction & Reaction Insights Topic Visualisation",
    maintainer="Sagar Narwade",
    maintainer_email="sagarnarwade147@gmail.com",
    packages=find_packages(),
    install_requires=[
        'praw==7.7.0',
        'numpy',
        'pandas',
        'spacy',
        'gensim',
        'pyLDAvis==3.4.1',
        'matplotlib',
        'tweepy',
        'wordcloud',
        'langdetect',
        'octis',
        'topic-wizard',
        'tweepy==3.9.0',
        'scikit-learn==1.3.0',
        'urllib3',
        'langdetect'
    ],
)
